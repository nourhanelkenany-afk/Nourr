document.addEventListener("DOMContentLoaded", () => {
  alert("Welcome to Burger House 🍔!");
});
